import random
def binary_search_rec(x, sorted_list):
    # this function uses binary search to determine whether an ordered array
    # contains a specified value.
    # return True if value x is in the list
    # return False if value x is not in the list
    # If you need, you can use a helper function.
    # TO DO
    pass
   

def binary_search_iter(x, sorted_list):
    # TO DO
    # return True if value x is in the list
    # return False if value x is not in the list
    pass
    
 



def main():
    sorted_list = []
    for i in range(100):
        sorted_list.append(random.randint(0, 100))
    sorted_list.sort()

    print("Testing recursive binary search ...")
    for i in range(5):
        value = random.randint(0, 100)
        answer = binary_search_rec(value, sorted_list)
        if (answer == True):
            print("List contains value", value)
        else:
            print("List does not contain value", value)

    print("Testing iterative binary search ...")
    for i in range(5):
        value = random.randint(0, 100)
        answer = binary_search_iter(value, sorted_list)
        if (answer == True):
            print("List contains value", value)
        else:
            print("List does not contain value", value)
    
main()









