class Polynomial:
	def __init__(self, coeffs):
		self.coeffs = coeffs

	#########  To do ##########



def main():
	# 1x^4 + 2x^3 + 3x^2 + 4x + 5
	coeffs = [1,2,3,4,5]
	poly = Polynomial(coeffs)
	print(poly.evaluate_at(2))   # 57
	print(poly.evaluate_at(3))   # 179
	print(poly)	 # Outputs: 1x^4 + 2x^3 + 3x^2 + 4x^1 + 5

	# 4x^3 + 6x^2 + 8x^1 + 10
	coeffs = [4,6,8,10]
	poly2 = Polynomial(coeffs)
	print(poly2)	 # Outputs: 4x^3 + 6x^2 + 8x^1 + 10
	poly += poly2
	print(poly)

main()