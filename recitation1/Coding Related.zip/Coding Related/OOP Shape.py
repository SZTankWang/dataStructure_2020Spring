class Shape:
	def __init__(self, name):
		self.name = name

	def get_name(self):
		_______________

class Circle:
	def __init__(self, name, radius):
		_______________

	def calc_area(self):
		_______________

	def calc_perimeter(self):
		_______________

class Rectangle:
	def __init__(self, name, width, height):
		_______________

	def calc_area(self):
		_______________

	def calc_perimeter(self):
		_______________

def main():
	circle1 = Circle("fancy", 5)
	print(circle1.calc_area())
	print(circle1.calc_perimeter())

	rectangle1 = Rectangle("lucky", 3, 4)
	print(rectangle1.calc_area())
	print(rectangle1.calc_perimeter())

if __name__ == '__main__':
    main()
	