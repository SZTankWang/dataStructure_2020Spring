class Student:
    def __init__(self, name, age, GPA):
        _______________
        _______________
        _______________


    def get_GPA(self):
        _______________

    def set_GPA(self, GPA):
        _______________


def main():
    bob = Student("Bob", 15, 3.0)
    print(bob.get_GPA())

    bob.set_GPA(4.0)
    print(bob.get_GPA())

if __name__ == '__main__':
    main()





