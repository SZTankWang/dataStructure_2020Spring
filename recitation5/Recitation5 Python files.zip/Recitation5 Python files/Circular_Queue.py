from queue import Empty
class ArrayQueue():

    DEFAULT_CAPACITY = 10
    
    def __init__(self):
        self._data = [None] * ArrayQueue.DEFAULT_CAPACITY
        self._size = 0
        self._front = 0

    def __len__(self):
        pass

    def is_empty(self):
        pass

    def first(self):
        ''' Return the value stored at the front of the queue '''
        pass

    def dequeue(self):
        ''' Remove and return the value stored at the front of the queue '''
        pass

    def enqueue(self, e):
        ''' Insert e at the end of the queue '''
        pass

    def __str__(self):
        ''' You can simply print self._data '''
        return "Incomplete!! Change this."

def main():
    # Empty Queue, size 10.
    queue = ArrayQueue()

    # Enqueue 0, 1, 2, 3, 4, 5, 6, 7
    for i in range(8):
        queue.enqueue(i)
    print(queue)   # [0, 1, 2, 3, 4, 5, 6, 7, None, None] 

    # Dequeue 5 times.
    for j in range(5):
        queue.dequeue()
    print(queue)  # [None, None, None, None, None, 5, 6, 7, None, None]

    # Enqueue 8, 9, 10, 11, 12
    for k in range(5):
        queue.enqueue(k + 8)
    print(queue)  # [10, 11, 12, None, None, 5, 6, 7, 8, 9]


if __name__ == '__main__':
    main()

