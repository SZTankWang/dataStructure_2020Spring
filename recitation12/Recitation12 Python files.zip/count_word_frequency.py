from probe_hash_map import ProbeHashMap

table = ProbeHashMap()
file = open("count_words.txt", "r")
# To do

max_word = ""
max_count = 0



print('The most frequent word is', max_word)
print('Its number of occurrences is', max_count)
