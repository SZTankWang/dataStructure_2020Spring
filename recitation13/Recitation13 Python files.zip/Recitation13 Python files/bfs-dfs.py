from graph import Graph

def BFS(g, s, discovered_list):
    """
    :param g: Graph -- the graph
    :param s: Vertex -- the starting vertex for BFS
    :param discovered_list: List[Vertex] -- use this to mark discovered vertices

    Perform BFS of the undiscovered portion of Graph g starting at Vertex s.
    
    :return: Nothing, discovered_list will contain BFS order as you mark.
    """
    # To do task 4
    pass

def DFS(g, s, discovered_list):
    """
    :param g: Graph -- the graph
    :param s: Vertex -- the starting vertex for DFS
    :param discovered_list: List[Vertex] -- use this to mark discovered vertices

    Perform DFS of the undiscovered portion of Graph g starting at Vertex s.
    
    :return: Nothing, discovered_list will contain DFS order as you mark.
    """
    # To do task 5
    pass



''' Draws the graph shown in recitation. '''
a = Graph()
# Add vertices
va = a.insert_vertex("A")
vb = a.insert_vertex("B")
vc = a.insert_vertex("C")
vd = a.insert_vertex("D")
ve = a.insert_vertex("E")
vf = a.insert_vertex("F")
vg = a.insert_vertex("G")
# Add edges
a.insert_edge(va, vc)
a.insert_edge(va, vd)
a.insert_edge(vc, vb)
a.insert_edge(vc, vd)
a.insert_edge(vc, ve)
a.insert_edge(ve, vf)
a.insert_edge(vf, vg)
a.insert_edge(vd, vg)
a.insert_edge(vb, vf)

print("------------------ Task 6 --------------------")
print("Your BFS result:")
discovered_list = []
BFS(a, va, discovered_list)
print(discovered_list)

print("------------------ Task 7 --------------------")
print("Your DFS result:")
discovered_list = []
DFS(a, va, discovered_list)
print(discovered_list)


